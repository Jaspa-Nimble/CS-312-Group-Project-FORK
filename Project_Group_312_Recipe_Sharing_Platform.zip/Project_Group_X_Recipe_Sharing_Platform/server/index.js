// STAND-IN Express server (Jasper Careless owns the final version).
// Mounts the two route files used by Brenden's search + details work.
require('dotenv').config();
const path = require('path');
const express = require('express');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use('/api/search', require('./routes/search'));
app.use('/api/recipes', require('./routes/recipes'));

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});

const PORT = process.env.PORT || 3000;
if (require.main === module) {
  app.listen(PORT, () => console.log(`Recipe Share running at http://localhost:${PORT}`));
}
module.exports = app;
