// STAND-IN connection pool (Jasper Careless owns the final version).
require('dotenv').config();
const { Pool } = require('pg');

module.exports = new Pool({ connectionString: process.env.DATABASE_URL });
