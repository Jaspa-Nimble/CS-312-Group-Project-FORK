// Brenden Cabrera - Phase 1: data for the recipe details view.
// (Jasper's recipe list / create routes will be added to this file.)
const express = require('express');
const pool = require('../db');

const router = express.Router();
const MAX_INT4 = 2147483647;

// GET /api/recipes/:id -> recipe, ordered ingredients, and instructions split into steps
router.get('/:id', async (req, res, next) => {
  try {
    if (!/^\d+$/.test(req.params.id)) {
      return res.status(400).json({ error: 'Invalid recipe id' });
    }
    const id = Number(req.params.id);
    if (id < 1 || id > MAX_INT4) return res.status(404).json({ error: 'Recipe not found' });

    const recipe = await pool.query(
      `SELECT r.id, r.title, r.description, r.instructions, r.cuisine, r.meal_type,
              r.cook_time_minutes, r.difficulty, r.dietary_tags, r.image_url,
              r.created_at, u.username AS author
         FROM recipes r JOIN users u ON u.id = r.user_id
        WHERE r.id = $1`,
      [id]
    );
    if (recipe.rows.length === 0) return res.status(404).json({ error: 'Recipe not found' });

    const ingredients = await pool.query(
      `SELECT name, quantity FROM recipe_ingredients
        WHERE recipe_id = $1 ORDER BY position, id`,
      [id]
    );

    const { instructions, ...rest } = recipe.rows[0];
    res.json({
      ...rest,
      ingredients: ingredients.rows,
      steps: instructions.split(/\r?\n/).map((s) => s.trim()).filter(Boolean),
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
